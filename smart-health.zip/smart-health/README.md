# Smart Health — Frontend

Aplicação React + Vite para o sistema Smart Health.

## Tecnologias
- React 18
- React Router DOM 6
- Vite 5
- Lucide React (ícones)

## Como rodar

```bash
npm install
npm run dev
```

Acesse: http://localhost:5173

## Rotas

| Rota | Página |
|------|--------|
| `/home` | Tela inicial com progresso do dia |
| `/videos` | Biblioteca de treinos/vídeos |
| `/programs` | Lembretes e programas semanais |
| `/progress` | Métricas e histórico de progresso |
| `/profile` | Perfil do usuário |

## Estrutura de Pastas

```
smart-health/
├── index.html
├── vite.config.js
├── package.json
└── src/
    ├── main.jsx              # Ponto de entrada
    ├── App.jsx               # Roteamento principal
    ├── components/
    │   ├── Header.jsx        # Cabeçalho com logo e ícone de perfil
    │   └── BottomNav.jsx     # Barra de navegação inferior fixa
    └── pages/
        ├── Home.jsx          # Tela Home (/home)
        ├── Videos.jsx        # Tela de Treinos/Vídeos (/videos)
        ├── Programs.jsx      # Tela de Programas (/programs)
        ├── Progress.jsx      # Tela de Progresso (/progress)
        └── Profile.jsx       # Tela de Perfil (/profile)
```

## Repositório GitHub

> Link do repositório: **[inserir aqui]**
