import React from 'react'
import { useNavigate, useLocation } from 'react-router-dom'

const s = {
  nav: {
    position: 'fixed', bottom: 0, left: 0, right: 0,
    background: '#fff', borderTop: '1px solid #e8e8e8',
    display: 'flex', justifyContent: 'space-around', alignItems: 'center',
    padding: '8px 0 12px', zIndex: 100,
    boxShadow: '0 -2px 10px rgba(0,0,0,0.06)',
  },
  item: {
    display: 'flex', flexDirection: 'column', alignItems: 'center',
    gap: 3, cursor: 'pointer', padding: '4px 16px',
    fontSize: 11, color: '#999', fontWeight: 500, border: 'none',
    background: 'none',
  },
  active: { color: '#2196F3' },
}

const tabs = [
  { path: '/home', label: 'Home', icon: HomeIcon },
  { path: '/videos', label: 'Treinos', icon: TrainingsIcon },
  { path: '/programs', label: 'Programas', icon: ProgramsIcon },
  { path: '/progress', label: 'Progresso', icon: ProgressIcon },
]

function HomeIcon({ color }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>
    </svg>
  )
}
function TrainingsIcon({ color }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="2"/><path d="M6.5 6.5a6 6 0 000 11M17.5 6.5a6 6 0 010 11M2 12h4M18 12h4"/>
    </svg>
  )
}
function ProgramsIcon({ color }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
    </svg>
  )
}
function ProgressIcon({ color }) {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>
    </svg>
  )
}

export default function BottomNav() {
  const navigate = useNavigate()
  const location = useLocation()

  return (
    <nav style={s.nav}>
      {tabs.map(({ path, label, icon: Icon }) => {
        const active = location.pathname === path
        const color = active ? '#2196F3' : '#999'
        return (
          <button key={path} style={{ ...s.item, ...(active ? s.active : {}) }} onClick={() => navigate(path)}>
            <Icon color={color} />
            {label}
          </button>
        )
      })}
    </nav>
  )
}
