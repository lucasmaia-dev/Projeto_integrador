import React, { useState } from 'react'
import Header from '../components/Header.jsx'
import BottomNav from '../components/BottomNav.jsx'

const DAYS = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb']
const WEEK_DAYS = ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Dom', 'Sáb']

function getWeekDates() {
  const today = new Date()
  const dow = today.getDay()
  const monday = new Date(today)
  monday.setDate(today.getDate() - ((dow + 6) % 7))
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(monday)
    d.setDate(monday.getDate() + i)
    return d
  })
}

const defaultReminders = [
  { id: 1, icon: '🏃', iconBg: '#2196F3', name: 'Corrida', time: '19:00', days: 'Seg, Qua, Sex', active: true },
  { id: 2, icon: '💊', iconBg: '#E91E63', name: 'Gliifage', time: '08:00', days: 'Seg, Ter, Qua, Qui, Sex', active: true },
  { id: 3, icon: '💧', iconBg: '#00BCD4', name: 'beber agua', time: '08:00', days: 'Seg, Ter, Qua, Qui, Sex, Dom, Sáb', active: true },
]

export default function Programs() {
  const today = new Date()
  const weekDates = getWeekDates()
  const [selectedDay, setSelectedDay] = useState(today.getDate())
  const [reminders, setReminders] = useState(defaultReminders)
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ name: '', time: '08:00', days: [] })

  const todayNum = today.getDate()
  const monthName = today.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })

  function toggleDay(day) {
    setForm(f => ({
      ...f,
      days: f.days.includes(day) ? f.days.filter(d => d !== day) : [...f.days, day],
    }))
  }

  function addReminder() {
    if (!form.name || form.days.length === 0) return
    setReminders(r => [...r, {
      id: Date.now(), icon: '⏰', iconBg: '#9C27B0',
      name: form.name, time: form.time,
      days: form.days.join(', '), active: true,
    }])
    setForm({ name: '', time: '08:00', days: [] })
    setShowModal(false)
  }

  function toggleActive(id) {
    setReminders(r => r.map(rem => rem.id === id ? { ...rem, active: !rem.active } : rem))
  }

  return (
    <div style={{ minHeight: '100vh', background: '#f8f9fa', paddingBottom: 80 }}>
      <Header />
      <div style={{ padding: '20px 16px' }}>
        <h2 style={{ fontSize: 22, fontWeight: 700, color: '#1a1a1a', marginBottom: 2 }}>Programas</h2>
        <p style={{ color: '#888', fontSize: 13, marginBottom: 16 }}>Gerencie seus lembretes e rotinas</p>

        {/* Calendar */}
        <div style={{
          background: 'linear-gradient(135deg,#26C6DA 0%,#00897B 100%)',
          borderRadius: 18, padding: 18, marginBottom: 16,
        }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
            <div>
              <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: 12, marginBottom: 2 }}>{monthName}</p>
              <p style={{ color: '#fff', fontWeight: 700, fontSize: 18 }}>
                {DAYS[today.getDay()]}, {todayNum}
              </p>
            </div>
            <span style={{ color: '#fff', fontSize: 22 }}>📅</span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 4 }}>
            {weekDates.map((d, i) => {
              const dn = d.getDate()
              const isSelected = dn === selectedDay
              const isToday = dn === todayNum
              return (
                <button key={i} onClick={() => setSelectedDay(dn)} style={{
                  display: 'flex', flexDirection: 'column', alignItems: 'center',
                  gap: 4, padding: '8px 4px', borderRadius: 10, border: 'none',
                  background: isSelected ? '#fff' : 'rgba(255,255,255,0.15)',
                  cursor: 'pointer',
                }}>
                  <span style={{ fontSize: 11, color: isSelected ? '#00ACC1' : 'rgba(255,255,255,0.7)' }}>
                    {WEEK_DAYS[i]}
                  </span>
                  <span style={{
                    fontSize: 16, fontWeight: 700,
                    color: isSelected ? '#00ACC1' : '#fff',
                  }}>{dn}</span>
                </button>
              )
            })}
          </div>
        </div>

        {/* Add Button */}
        <button onClick={() => setShowModal(true)} style={{
          width: '100%', padding: '14px', borderRadius: 14,
          border: '2px dashed #26C6DA', background: '#fff',
          color: '#26C6DA', fontWeight: 600, fontSize: 15,
          cursor: 'pointer', marginBottom: 24,
        }}>+ Adicionar Lembrete</button>

        {/* Reminders List */}
        <h3 style={{ fontSize: 16, fontWeight: 700, color: '#1a1a1a', marginBottom: 12 }}>Seus Lembretes</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {reminders.map(rem => (
            <div key={rem.id} style={{
              background: '#fff', borderRadius: 16, padding: '14px 16px',
              display: 'flex', alignItems: 'center', gap: 14,
              boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
            }}>
              <div style={{
                width: 44, height: 44, borderRadius: 12, background: rem.iconBg,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 20, flexShrink: 0,
              }}>{rem.icon}</div>
              <div style={{ flex: 1 }}>
                <p style={{ fontWeight: 600, fontSize: 15, color: '#1a1a1a', marginBottom: 3 }}>{rem.name}</p>
                <p style={{ fontSize: 12, color: '#888' }}>⏰ {rem.time} · {rem.days}</p>
              </div>
              <div
                onClick={() => toggleActive(rem.id)}
                style={{
                  width: 14, height: 14, borderRadius: '50%',
                  background: rem.active ? '#4CAF50' : '#ccc',
                  cursor: 'pointer', flexShrink: 0,
                }}
              />
            </div>
          ))}
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.5)',
          display: 'flex', alignItems: 'flex-end', zIndex: 200,
        }}>
          <div style={{
            background: '#fff', borderRadius: '20px 20px 0 0',
            padding: 24, width: '100%',
          }}>
            <h3 style={{ fontSize: 18, fontWeight: 700, marginBottom: 20 }}>Novo Lembrete</h3>
            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 13, color: '#666', display: 'block', marginBottom: 6 }}>Nome da atividade</label>
              <input
                value={form.name}
                onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                placeholder="Ex: Corrida, Medicamento..."
                style={{
                  width: '100%', padding: '12px', borderRadius: 10,
                  border: '1.5px solid #e0e0e0', fontSize: 14, outline: 'none',
                  boxSizing: 'border-box',
                }}
              />
            </div>
            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 13, color: '#666', display: 'block', marginBottom: 6 }}>Horário</label>
              <input
                type="time" value={form.time}
                onChange={e => setForm(f => ({ ...f, time: e.target.value }))}
                style={{
                  width: '100%', padding: '12px', borderRadius: 10,
                  border: '1.5px solid #e0e0e0', fontSize: 14, outline: 'none',
                  boxSizing: 'border-box',
                }}
              />
            </div>
            <div style={{ marginBottom: 20 }}>
              <label style={{ fontSize: 13, color: '#666', display: 'block', marginBottom: 8 }}>Dias da semana</label>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                {WEEK_DAYS.map(d => (
                  <button key={d} onClick={() => toggleDay(d)} style={{
                    padding: '6px 12px', borderRadius: 8, border: 'none',
                    background: form.days.includes(d) ? '#26C6DA' : '#f0f0f0',
                    color: form.days.includes(d) ? '#fff' : '#555',
                    fontWeight: form.days.includes(d) ? 600 : 400,
                    fontSize: 13, cursor: 'pointer',
                  }}>{d}</button>
                ))}
              </div>
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={() => setShowModal(false)} style={{
                flex: 1, padding: '13px', borderRadius: 12,
                border: '1.5px solid #e0e0e0', background: '#fff',
                fontSize: 15, cursor: 'pointer', color: '#555',
              }}>Cancelar</button>
              <button onClick={addReminder} style={{
                flex: 1, padding: '13px', borderRadius: 12,
                border: 'none',
                background: 'linear-gradient(135deg,#26C6DA,#00897B)',
                color: '#fff', fontSize: 15, fontWeight: 600, cursor: 'pointer',
              }}>Salvar</button>
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  )
}
