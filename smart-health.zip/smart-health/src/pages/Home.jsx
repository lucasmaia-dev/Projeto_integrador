import React, { useState } from 'react'
import Header from '../components/Header.jsx'
import BottomNav from '../components/BottomNav.jsx'
import { useNavigate } from 'react-router-dom'

function getGreeting() {
  const h = new Date().getHours()
  if (h < 12) return 'Bom dia'
  if (h < 18) return 'Boa tarde'
  return 'Boa noite'
}

function getDate() {
  return new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })
}

const quickAccess = [
  { label: 'Treinos', path: '/videos', color: '#2196F3', icon: '🏋️' },
  { label: 'Vídeos', path: '/videos', color: '#00BCD4', icon: '▶️' },
  { label: 'Programas', path: '/programs', color: '#9C27B0', icon: '📅' },
  { label: 'Profissionais', path: '/profile', color: '#FF5722', icon: '👤' },
  { label: 'Progresso', path: '/progress', color: '#009688', icon: '📈' },
  { label: 'Bem-estar', path: '/home', color: '#E91E63', icon: '❤️' },
]

const news = [
  { tag: '❤️', title: 'Dia da Saúde e Nutrição', sub: 'Confira dicas especiais para uma alimentação saudável', color: '#E91E63' },
  { tag: '🧘', title: 'Mindfulness & Saúde Mental', sub: 'Como 10 minutos por dia podem transformar seu bem-estar', color: '#9C27B0' },
  { tag: '💤', title: 'Qualidade do Sono', sub: 'A importância do descanso para sua performance', color: '#3F51B5' },
]

const slides = [
  { category: 'Sem Acessórios', title: 'Treino Funcional', bg: 'linear-gradient(135deg,#26C6DA 0%,#00838F 100%)' },
  { category: 'Cardio', title: 'HIIT Explosivo', bg: 'linear-gradient(135deg,#42A5F5 0%,#1565C0 100%)' },
  { category: 'Força', title: 'Musculação Total', bg: 'linear-gradient(135deg,#66BB6A 0%,#2E7D32 100%)' },
]

export default function Home() {
  const navigate = useNavigate()
  const [slide, setSlide] = useState(0)

  return (
    <div style={{ minHeight: '100vh', background: '#f8f9fa', paddingBottom: 80 }}>
      <Header />
      <div style={{ padding: '20px 16px' }}>

        {/* Greeting */}
        <p style={{ color: '#666', fontSize: 14, marginBottom: 2 }}>{getGreeting()}</p>
        <h2 style={{ fontSize: 24, fontWeight: 700, color: '#1a1a1a', marginBottom: 2 }}>Lucas! 👋</h2>
        <p style={{ color: '#999', fontSize: 13, marginBottom: 24 }}>{getDate()}</p>

        {/* Progress Today */}
        <h3 style={{ fontSize: 16, fontWeight: 700, color: '#1a1a1a', marginBottom: 12 }}>Progresso de Hoje</h3>
        <div style={{
          background: 'linear-gradient(135deg,#26C6DA 0%,#00897B 100%)',
          borderRadius: 16, padding: 16, marginBottom: 24,
        }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            {[
              { icon: '👟', label: 'Passos', value: '0', unit: '' },
              { icon: '🔥', label: 'Calorias', value: '0', unit: 'kcal' },
              { icon: '💧', label: 'Água', value: '0', unit: 'L' },
              { icon: '⏱', label: 'Exercício', value: '0', unit: 'min' },
            ].map(({ icon, label, value, unit }) => (
              <div key={label} style={{
                background: 'rgba(255,255,255,0.15)', borderRadius: 12, padding: '12px 14px',
              }}>
                <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: 12, marginBottom: 4 }}>{icon} {label}</p>
                <p style={{ color: '#fff', fontSize: 20, fontWeight: 700 }}>{value}<span style={{ fontSize: 13, fontWeight: 400 }}>{unit}</span></p>
                <div style={{ height: 4, background: 'rgba(255,255,255,0.2)', borderRadius: 2, marginTop: 8 }}>
                  <div style={{ width: '5%', height: '100%', background: '#fff', borderRadius: 2 }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Featured Carousel */}
        <h3 style={{ fontSize: 16, fontWeight: 700, color: '#1a1a1a', marginBottom: 12 }}>Em Destaque</h3>
        <div style={{ position: 'relative', marginBottom: 24 }}>
          <div style={{
            background: slides[slide].bg,
            borderRadius: 16, padding: '24px 20px', minHeight: 130,
            display: 'flex', flexDirection: 'column', justifyContent: 'flex-end',
            cursor: 'pointer', overflow: 'hidden', position: 'relative',
          }}>
            <div style={{
              position: 'absolute', top: 0, right: 0, bottom: 0, left: 0,
              background: 'url("https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400") center/cover',
              opacity: 0.3,
            }} />
            <div style={{ position: 'relative' }}>
              <p style={{ color: 'rgba(255,255,255,0.85)', fontSize: 12, marginBottom: 4 }}>{slides[slide].category}</p>
              <h4 style={{ color: '#fff', fontSize: 20, fontWeight: 700, marginBottom: 12 }}>{slides[slide].title}</h4>
              <button onClick={() => navigate('/videos')} style={{
                background: 'rgba(255,255,255,0.25)', border: '1px solid rgba(255,255,255,0.5)',
                borderRadius: 20, padding: '6px 16px', color: '#fff', fontSize: 13,
                cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6, width: 'fit-content',
              }}>▶ Começar agora</button>
            </div>
          </div>
          {/* Dots */}
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 6, marginTop: 8 }}>
            {slides.map((_, i) => (
              <button key={i} onClick={() => setSlide(i)} style={{
                width: i === slide ? 20 : 8, height: 8, borderRadius: 4,
                background: i === slide ? '#26C6DA' : '#ccc',
                border: 'none', cursor: 'pointer', padding: 0, transition: 'all .2s',
              }} />
            ))}
          </div>
        </div>

        {/* Quick Access */}
        <h3 style={{ fontSize: 16, fontWeight: 700, color: '#1a1a1a', marginBottom: 12 }}>Acesso Rápido</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 12, marginBottom: 24 }}>
          {quickAccess.map(({ label, path, color, icon }) => (
            <button key={label} onClick={() => navigate(path)} style={{
              background: '#fff', border: 'none', borderRadius: 14, padding: '16px 8px',
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
              cursor: 'pointer', boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
            }}>
              <div style={{
                width: 44, height: 44, borderRadius: 12, background: color,
                display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20,
              }}>{icon}</div>
              <span style={{ fontSize: 12, color: '#444', fontWeight: 500 }}>{label}</span>
            </button>
          ))}
        </div>

        {/* News */}
        <h3 style={{ fontSize: 16, fontWeight: 700, color: '#1a1a1a', marginBottom: 12 }}>Notícias & Dicas</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {news.map(({ tag, title, sub, color }) => (
            <div key={title} style={{
              background: '#fff', borderRadius: 14, padding: 14,
              display: 'flex', alignItems: 'center', gap: 14,
              boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
            }}>
              <div style={{
                width: 52, height: 52, borderRadius: 12,
                background: `${color}20`, display: 'flex', alignItems: 'center',
                justifyContent: 'center', fontSize: 22, flexShrink: 0,
              }}>{tag}</div>
              <div>
                <p style={{ fontWeight: 600, fontSize: 14, color: '#1a1a1a', marginBottom: 3 }}>{title}</p>
                <p style={{ fontSize: 12, color: '#888' }}>{sub}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      <BottomNav />
    </div>
  )
}
