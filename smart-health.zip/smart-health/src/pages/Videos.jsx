import React, { useState } from 'react'
import Header from '../components/Header.jsx'
import BottomNav from '../components/BottomNav.jsx'

const categories = ['Todos', 'Emagrecimento', 'Força', 'Funcional', 'Cardio', 'Mobilidade']

const videos = [
  {
    id: 1, title: 'HIIT Explosivo', level: 'Avançado', levelColor: '#FF5722',
    duration: 15, views: '18.3k', premium: true, category: 'Cardio',
    img: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400',
  },
  {
    id: 2, title: 'Exercícios em Casa - Funcional', level: 'Iniciante', levelColor: '#4CAF50',
    duration: 20, views: '25.0k', premium: false, category: 'Funcional',
    img: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=400',
  },
  {
    id: 3, title: 'Queime Muita Caloria - HIIT', level: 'Intermediário', levelColor: '#FF9800',
    duration: 30, views: '12.1k', premium: false, category: 'Emagrecimento',
    img: 'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=400',
  },
  {
    id: 4, title: 'Treino de Força Total', level: 'Avançado', levelColor: '#FF5722',
    duration: 45, views: '9.8k', premium: true, category: 'Força',
    img: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400',
  },
  {
    id: 5, title: 'Yoga para Iniciantes', level: 'Iniciante', levelColor: '#4CAF50',
    duration: 25, views: '31.2k', premium: false, category: 'Mobilidade',
    img: 'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=400',
  },
  {
    id: 6, title: 'Abdômen Definido', level: 'Intermediário', levelColor: '#FF9800',
    duration: 18, views: '22.7k', premium: false, category: 'Funcional',
    img: 'https://images.unsplash.com/photo-1549060279-7e168fcee0c2?w=400',
  },
]

export default function Videos() {
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('Todos')
  const [tab, setTab] = useState('Populares')

  const filtered = videos
    .filter(v => category === 'Todos' || v.category === category)
    .filter(v => v.title.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => tab === 'Populares'
      ? parseFloat(b.views) - parseFloat(a.views)
      : b.id - a.id)

  return (
    <div style={{ minHeight: '100vh', background: '#f8f9fa', paddingBottom: 80 }}>
      <Header />
      <div style={{ padding: '20px 16px' }}>
        <h2 style={{ fontSize: 22, fontWeight: 700, color: '#1a1a1a', marginBottom: 2 }}>Vídeos</h2>
        <p style={{ color: '#888', fontSize: 13, marginBottom: 16 }}>Encontre o treino ideal para você</p>

        {/* Search */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10,
          background: '#fff', borderRadius: 12, padding: '10px 14px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.06)', marginBottom: 16,
        }}>
          <span style={{ color: '#aaa' }}>🔍</span>
          <input
            value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Buscar treinos..."
            style={{ border: 'none', outline: 'none', flex: 1, fontSize: 14, color: '#333', background: 'transparent' }}
          />
        </div>

        {/* Categories */}
        <div style={{ display: 'flex', gap: 8, overflowX: 'auto', marginBottom: 16, paddingBottom: 4 }}>
          {categories.map(cat => (
            <button key={cat} onClick={() => setCategory(cat)} style={{
              padding: '7px 16px', borderRadius: 20, border: 'none',
              background: category === cat ? '#26C6DA' : '#fff',
              color: category === cat ? '#fff' : '#555',
              fontWeight: category === cat ? 600 : 400,
              fontSize: 13, cursor: 'pointer', whiteSpace: 'nowrap',
              boxShadow: category === cat ? '0 2px 8px rgba(38,198,218,0.35)' : '0 1px 4px rgba(0,0,0,0.08)',
            }}>{cat}</button>
          ))}
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', gap: 24, borderBottom: '1px solid #eee', marginBottom: 16 }}>
          {['Populares', 'Recentes'].map(t => (
            <button key={t} onClick={() => setTab(t)} style={{
              border: 'none', background: 'none', padding: '6px 0',
              fontSize: 14, fontWeight: 600, cursor: 'pointer',
              color: tab === t ? '#26C6DA' : '#999',
              borderBottom: tab === t ? '2px solid #26C6DA' : '2px solid transparent',
            }}>{t}</button>
          ))}
        </div>

        {/* Video Cards */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          {filtered.map(v => (
            <div key={v.id} style={{ background: '#fff', borderRadius: 16, overflow: 'hidden', boxShadow: '0 2px 12px rgba(0,0,0,0.08)' }}>
              <div style={{ position: 'relative' }}>
                <img src={v.img} alt={v.title} style={{ width: '100%', height: 180, objectFit: 'cover', display: 'block' }} />
                {v.premium && (
                  <div style={{
                    position: 'absolute', top: 10, right: 10,
                    background: '#FF9800', borderRadius: 12, padding: '3px 10px',
                    color: '#fff', fontSize: 12, fontWeight: 600,
                  }}>⭐ Premium</div>
                )}
                <div style={{
                  position: 'absolute', inset: 0,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <div style={{
                    width: 44, height: 44, borderRadius: '50%',
                    background: 'rgba(255,255,255,0.9)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 18, cursor: 'pointer', boxShadow: '0 2px 8px rgba(0,0,0,0.2)',
                  }}>▶</div>
                </div>
                <div style={{
                  position: 'absolute', bottom: 10, right: 10,
                  background: 'rgba(0,0,0,0.6)', borderRadius: 8, padding: '2px 8px',
                  color: '#fff', fontSize: 12,
                }}>⏱ {v.duration} min</div>
              </div>
              <div style={{ padding: '12px 14px' }}>
                <p style={{ fontWeight: 700, fontSize: 15, color: '#1a1a1a', marginBottom: 6 }}>{v.title}</p>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{
                    background: `${v.levelColor}20`, color: v.levelColor,
                    padding: '3px 10px', borderRadius: 8, fontSize: 12, fontWeight: 600,
                  }}>{v.level}</span>
                  <span style={{ color: '#999', fontSize: 12 }}>🔥 {v.views} views</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <BottomNav />
    </div>
  )
}
