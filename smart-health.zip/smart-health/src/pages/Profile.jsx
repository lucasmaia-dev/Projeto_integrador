import React from 'react'
import Header from '../components/Header.jsx'
import BottomNav from '../components/BottomNav.jsx'

const menuItems = [
  { icon: '👑', label: 'Plano Premium', badge: 'Novo', color: '#FF9800' },
  { icon: '❤️', label: 'Meus Favoritos', badge: null, color: '#E91E63' },
  { icon: '🔔', label: 'Lembretes', badge: null, color: '#9C27B0' },
  { icon: '📈', label: 'Histórico de Progresso', badge: null, color: '#009688' },
  { icon: '⚙️', label: 'Configurações', badge: null, color: '#607D8B' },
  { icon: '❓', label: 'Ajuda e Suporte', badge: null, color: '#795548' },
  { icon: '🔒', label: 'Privacidade', badge: null, color: '#455A64' },
]

export default function Profile() {
  return (
    <div style={{ minHeight: '100vh', background: '#f8f9fa', paddingBottom: 80 }}>
      <Header />
      <div style={{ padding: '20px 16px' }}>
        <h2 style={{ fontSize: 22, fontWeight: 700, color: '#1a1a1a', marginBottom: 16 }}>Perfil</h2>

        {/* User Card */}
        <div style={{
          background: 'linear-gradient(135deg,#26C6DA 0%,#00897B 100%)',
          borderRadius: 18, padding: 20, marginBottom: 16,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 16 }}>
            <div style={{ position: 'relative' }}>
              <div style={{
                width: 64, height: 64, borderRadius: '50%',
                background: 'rgba(255,255,255,0.25)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 28,
              }}>👤</div>
              <div style={{
                position: 'absolute', bottom: 0, right: 0,
                width: 20, height: 20, borderRadius: '50%',
                background: '#fff', display: 'flex', alignItems: 'center',
                justifyContent: 'center', fontSize: 11, boxShadow: '0 1px 4px rgba(0,0,0,0.2)',
              }}>✏️</div>
            </div>
            <div>
              <p style={{ color: '#fff', fontWeight: 700, fontSize: 18 }}>Lucas Augusto Maia</p>
              <p style={{ color: 'rgba(255,255,255,0.75)', fontSize: 13, marginBottom: 6 }}>lucasmaiaaugusto@gmail.com</p>
              <div style={{ display: 'flex', gap: 10 }}>
                <span style={{
                  background: 'rgba(255,255,255,0.2)', borderRadius: 8, padding: '2px 10px',
                  color: '#fff', fontSize: 12,
                }}>Plano Free</span>
                <span style={{ color: 'rgba(255,255,255,0.7)', fontSize: 12 }}>Desde nov 2025</span>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div style={{
            display: 'grid', gridTemplateColumns: 'repeat(3,1fr)',
            background: 'rgba(255,255,255,0.15)', borderRadius: 14,
          }}>
            {[
              { icon: '🎯', value: '1', label: 'Treinos' },
              { icon: '📈', value: '1.537', label: 'Calorias' },
              { icon: '🏆', value: '1 dias', label: 'Sequência' },
            ].map(({ icon, value, label }) => (
              <div key={label} style={{
                padding: '14px 8px', textAlign: 'center',
                borderRight: label !== 'Sequência' ? '1px solid rgba(255,255,255,0.2)' : 'none',
              }}>
                <p style={{ fontSize: 18, marginBottom: 4 }}>{icon}</p>
                <p style={{ color: '#fff', fontWeight: 700, fontSize: 16, marginBottom: 2 }}>{value}</p>
                <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: 11 }}>{label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Premium Banner */}
        <div style={{
          background: 'linear-gradient(135deg,#FF9800,#F57C00)',
          borderRadius: 16, padding: '18px 20px', marginBottom: 20,
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          cursor: 'pointer',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <span style={{ fontSize: 28 }}>👑</span>
            <div>
              <p style={{ color: '#fff', fontWeight: 700, fontSize: 16 }}>Seja Premium</p>
              <p style={{ color: 'rgba(255,255,255,0.85)', fontSize: 13 }}>Desbloqueie todos os recursos</p>
            </div>
          </div>
          <span style={{ color: '#fff', fontSize: 20 }}>›</span>
        </div>

        {/* Menu */}
        <div style={{
          background: '#fff', borderRadius: 16,
          boxShadow: '0 2px 8px rgba(0,0,0,0.06)', overflow: 'hidden',
        }}>
          {menuItems.map(({ icon, label, badge, color }, i) => (
            <div key={label}>
              <div style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                padding: '16px 18px', cursor: 'pointer',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                  <span style={{ fontSize: 20 }}>{icon}</span>
                  <span style={{ fontSize: 15, color: '#1a1a1a', fontWeight: 500 }}>{label}</span>
                  {badge && (
                    <span style={{
                      background: '#E8F5E9', color: '#4CAF50',
                      borderRadius: 8, padding: '2px 8px', fontSize: 12, fontWeight: 600,
                    }}>{badge}</span>
                  )}
                </div>
                <span style={{ color: '#ccc', fontSize: 16 }}>›</span>
              </div>
              {i < menuItems.length - 1 && (
                <div style={{ height: 1, background: '#f5f5f5', marginLeft: 54 }} />
              )}
            </div>
          ))}
        </div>

        {/* Logout */}
        <button style={{
          width: '100%', marginTop: 16, padding: '14px',
          borderRadius: 14, border: '1.5px solid #ffcdd2',
          background: '#fff', color: '#e53935',
          fontSize: 15, fontWeight: 600, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        }}>
          ↩ Sair da conta
        </button>
      </div>
      <BottomNav />
    </div>
  )
}
