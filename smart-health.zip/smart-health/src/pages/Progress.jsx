import React, { useState } from 'react'
import Header from '../components/Header.jsx'
import BottomNav from '../components/BottomNav.jsx'

const metrics = [
  { label: 'Passos', icon: '👟', value: 0, meta: 10000, unit: '', color: '#2196F3', bg: '#E3F2FD' },
  { label: 'Calorias', icon: '🔥', value: 0, meta: 500, unit: '', color: '#FF9800', bg: '#FFF3E0' },
  { label: 'Água (ml)', icon: '💧', value: 0, meta: 2000, unit: '', color: '#00BCD4', bg: '#E0F7FA' },
  { label: 'Exercício', icon: '⏱', value: 0, meta: 60, unit: '', color: '#4CAF50', bg: '#E8F5E9' },
]

const weekDays = ['terça', 'quarta', 'quinta', 'sexta', 'sábado', 'domingo']
const weekData = [40, 65, 30, 80, 55, 70]

const history = [
  { day: 'Terça-Feira', date: '02/12', steps: 8000, cal: 1537, exercise: 45 },
  { day: 'Segunda-Feira', date: '01/12', steps: 6500, cal: 1210, exercise: 30 },
  { day: 'Domingo', date: '30/11', steps: 3200, cal: 890, exercise: 20 },
]

export default function Progress() {
  const [tab, setTab] = useState('Semanal')
  const pct = 0

  return (
    <div style={{ minHeight: '100vh', background: '#f8f9fa', paddingBottom: 80 }}>
      <Header />
      <div style={{ padding: '20px 16px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <div>
            <h2 style={{ fontSize: 22, fontWeight: 700, color: '#1a1a1a', marginBottom: 2 }}>Progresso</h2>
            <p style={{ color: '#888', fontSize: 13 }}>Acompanhe sua evolução</p>
          </div>
          <button style={{
            width: 36, height: 36, borderRadius: '50%',
            background: 'linear-gradient(135deg,#26C6DA,#00897B)',
            border: 'none', color: '#fff', fontSize: 20,
            cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>+</button>
        </div>

        {/* Meta Card */}
        <div style={{
          background: 'linear-gradient(135deg,#26C6DA 0%,#00897B 100%)',
          borderRadius: 18, padding: '20px', marginBottom: 20,
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        }}>
          <div>
            <p style={{ color: 'rgba(255,255,255,0.8)', fontSize: 13, marginBottom: 6 }}>Meta de Movimentação</p>
            <p style={{ color: '#fff', fontSize: 32, fontWeight: 700, marginBottom: 4 }}>0</p>
            <p style={{ color: 'rgba(255,255,255,0.7)', fontSize: 13, marginBottom: 12 }}>de 10.000 passos</p>
            <div style={{ display: 'flex', gap: 16 }}>
              <span style={{ color: 'rgba(255,255,255,0.9)', fontSize: 13 }}>🔥 0kcal</span>
              <span style={{ color: 'rgba(255,255,255,0.9)', fontSize: 13 }}>⏱ 0min</span>
            </div>
          </div>
          {/* Circular Progress */}
          <div style={{ position: 'relative', width: 80, height: 80 }}>
            <svg width="80" height="80" viewBox="0 0 80 80">
              <circle cx="40" cy="40" r="34" fill="none" stroke="rgba(255,255,255,0.25)" strokeWidth="8" />
              <circle
                cx="40" cy="40" r="34" fill="none"
                stroke="#fff" strokeWidth="8"
                strokeDasharray={`${2 * Math.PI * 34 * pct / 100} ${2 * Math.PI * 34}`}
                strokeLinecap="round" transform="rotate(-90 40 40)"
              />
            </svg>
            <div style={{
              position: 'absolute', inset: 0,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: '#fff', fontSize: 14, fontWeight: 700,
            }}>{pct}%</div>
          </div>
        </div>

        {/* Metric Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 20 }}>
          {metrics.map(m => (
            <div key={m.label} style={{
              background: m.bg, borderRadius: 16, padding: '16px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.04)',
            }}>
              <p style={{ color: '#666', fontSize: 13, marginBottom: 6 }}>{m.icon} {m.label}</p>
              <p style={{ fontSize: 24, fontWeight: 700, color: '#1a1a1a', marginBottom: 4 }}>{m.value}</p>
              <p style={{ fontSize: 12, color: '#999' }}>Meta: {m.meta.toLocaleString('pt-BR')}</p>
              <div style={{ height: 4, background: 'rgba(0,0,0,0.08)', borderRadius: 2, marginTop: 10 }}>
                <div style={{
                  width: `${Math.min((m.value / m.meta) * 100, 100)}%`,
                  height: '100%', background: m.color, borderRadius: 2,
                }} />
              </div>
            </div>
          ))}
        </div>

        {/* Tab */}
        <div style={{ display: 'flex', background: '#fff', borderRadius: 12, padding: 4, marginBottom: 16, boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}>
          {['Semanal', 'Mensal'].map(t => (
            <button key={t} onClick={() => setTab(t)} style={{
              flex: 1, padding: '10px', borderRadius: 10, border: 'none',
              background: tab === t ? '#26C6DA' : 'transparent',
              color: tab === t ? '#fff' : '#666',
              fontWeight: 600, fontSize: 14, cursor: 'pointer',
            }}>{t}</button>
          ))}
        </div>

        {/* Chart */}
        <div style={{
          background: '#fff', borderRadius: 16, padding: '16px',
          boxShadow: '0 2px 8px rgba(0,0,0,0.06)', marginBottom: 20,
        }}>
          <p style={{ fontWeight: 700, fontSize: 15, marginBottom: 16 }}>Atividade {tab}</p>
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 6, height: 80 }}>
            {weekData.map((v, i) => (
              <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4 }}>
                <div style={{
                  width: '100%', height: `${v}%`, background: 'linear-gradient(180deg,#26C6DA,#00897B)',
                  borderRadius: 4, minHeight: 3,
                }} />
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 6, marginTop: 6 }}>
            {weekDays.map(d => (
              <p key={d} style={{ flex: 1, textAlign: 'center', fontSize: 10, color: '#aaa' }}>{d}</p>
            ))}
          </div>
        </div>

        {/* History */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, color: '#1a1a1a' }}>Histórico de Progresso</h3>
          <span style={{ color: '#26C6DA', fontSize: 13, cursor: 'pointer' }}>Ver mais ›</span>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {history.map(h => (
            <div key={h.day} style={{
              background: '#fff', borderRadius: 14, padding: '14px 16px',
              boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                <p style={{ fontWeight: 600, fontSize: 15, color: '#1a1a1a' }}>{h.day}</p>
                <p style={{ fontSize: 13, color: '#999' }}>{h.date}</p>
              </div>
              <div style={{ display: 'flex', gap: 16 }}>
                <span style={{ fontSize: 13, color: '#2196F3' }}>👟 {h.steps.toLocaleString('pt-BR')}</span>
                <span style={{ fontSize: 13, color: '#FF9800' }}>🔥 {h.cal.toLocaleString('pt-BR')}kcal</span>
                <span style={{ fontSize: 13, color: '#4CAF50' }}>⏱ {h.exercise}min</span>
              </div>
            </div>
          ))}
        </div>
      </div>
      <BottomNav />
    </div>
  )
}
